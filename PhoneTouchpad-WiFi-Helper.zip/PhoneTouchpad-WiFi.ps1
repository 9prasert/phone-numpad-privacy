﻿# Phone Touchpad - โปรแกรมช่วยฝั่งโน้ตบุ๊กสำหรับโหมด Wi-Fi
# รับการขยับ/การกดจากแอปบนมือถือผ่าน Wi-Fi (UDP เข้ารหัส) แล้วสั่งเมาส์และคีย์บอร์ดของ Windows
# เปิดด้วย Start-Touchpad-WiFi.bat — ไม่ต้องติดตั้งอะไรเพิ่ม ไม่ต้องใช้สิทธิ์ผู้ดูแลระบบ
#
# โน้ตบุ๊กเป็นฝ่ายส่งออกไปหามือถือก่อนเสมอ (ประกาศตัวทุก 1 วินาที) จึงไม่ต้องเปิดพอร์ตขาเข้าใน Windows Firewall
#
# สำหรับทดสอบ:  -TestCode ABCDEFGH  ใช้รหัสจับคู่ตายตัว (ไม่บันทึก)
#               -LogReports <ไฟล์>  จดรายงานที่ได้รับลงไฟล์แทนการสั่งเมาส์/คีย์บอร์ดจริง
#               -NoUi -Seconds N    ไม่เปิดหน้าต่าง ทำงาน N วินาทีแล้วจบ
#               -AutoAllow          อนุญาตคำขอจับคู่แบบกดปุ่มให้เอง — มีผลเฉพาะเมื่อใช้ -TestCode หรือตั้ง PTW_CONFIG_DIR
#               PTW_CONFIG_DIR      (ตัวแปรแวดล้อม) โฟลเดอร์เก็บการตั้งค่าแยกสำหรับทดสอบ ไม่แตะการจับคู่จริงของผู้ใช้
param(
    [string]$TestCode = '',
    [string]$LogReports = '',
    [switch]$NoUi,
    [int]$Seconds = 0,
    [switch]$AutoAllow,
    [switch]$Startup     # ใช้โดยรายการเปิดเองตอนล็อกอิน: เริ่มแบบไม่เด้งหน้าต่าง อยู่ที่ไอคอนข้างนาฬิกา
)

$src = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

public static class PtwHelper
{
    const int PORT = 34870;
    const int T_BEACON = 1, T_HELLO = 2, T_WELCOME = 3, T_DATA = 4, T_ACK = 5, T_REJECT = 6;
    // จับคู่แบบกดอนุญาต (ตั้งแต่โปรแกรมช่วย 1.0.2 / แอป 1.24) — ECDH P-256 + เทียบเลข 6 หลัก แบบ Bluetooth numeric comparison
    //   7 PAIR1 (มือถือ→PC)  helperId16 · pkA65 · ความยาวชื่อ1 · ชื่อมือถือ
    //   8 PAIR2 (PC→มือถือ)  helperId16 · pkB65 · commit16        commit = SHA256("ptw-commit"|pkB|pkA|nB)[:16]
    //   9 PAIR3 (มือถือ→PC)  helperId16 · tag16 · nA16            tag = SHA256(pkA)[:16]  (ส่งซ้ำระหว่างรอผู้ใช้กด)
    //  10 PAIR4 (PC→มือถือ)  helperId16 · tag16 · nB16 · state1 · mac16   state 0 รอ / 1 อนุญาต / 2 ไม่อนุญาต
    //   K = HMAC(SHA256(Z), "ptw-pairkey"|pkA|pkB|nA|nB) · เลข = SHA256("ptw-sas"|pkA|pkB|nA|nB) 4 ไบต์แรก mod 1,000,000
    //   mac = HMAC(K, "ptw-paired"|state|tag)[:16]
    // PC เปิดเผย nB หลังได้ nA แล้วเท่านั้น (commit ผูกไว้ก่อน) ผู้ดักกลางทางจึงเลือกค่าให้เลขตรงกันไม่ได้ — โอกาส 1 ในล้านต่อครั้ง
    const int T_PAIR1 = 7, T_PAIR2 = 8, T_PAIR3 = 9, T_PAIR4 = 10;
    const int CAP_TAP_PAIR = 1;   // ไบต์ต่อท้าย BEACON: บอกแอปว่าจับคู่แบบกดอนุญาตได้ (แอปรุ่นเก่าไม่อ่านไบต์นี้)
    const int MAX_PAIRED = 8;
    static readonly byte[] MAGIC = { (byte)'P', (byte)'T', (byte)'W', (byte)'1' };
    const string ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    class Paired { public byte[] key; public string name; }

    class Pairing
    {
        public byte[] pkA, tag, pkB, nB, nA, zh, K, commit;
        public string name;
        public IPEndPoint from;
        public int sas = -1, state;
        public long created;
    }

    static readonly List<Paired> paired = new List<Paired>();
    static Pairing pairing;
    // เครื่องที่ผู้ใช้เพิ่งกด "ไม่อนุญาต": ไม่รับคำขอใหม่จาก IP นั้นช่วงหนึ่ง นานขึ้นทุกครั้งที่ถูกปฏิเสธซ้ำ (10 วิ, 40 วิ, 160 วิ, สูงสุด 10 นาที)
    // กันเครื่องอื่นในเครือข่ายเดียวกันส่งคำขอรัวๆ ให้หน้าต่างถามเด้งไม่หยุด — กดพลาดครั้งแรกยังลองใหม่ได้ใน 10 วินาที
    class Refused { public int count; public long until; }
    static readonly Dictionary<string, Refused> refused = new Dictionary<string, Refused>();
    static long lastPairStart;
    static bool autoAllow, testMode;

    class Session
    {
        public byte[] sid, enc, mac;
        public long txCtr, rxCtr;
        public IPEndPoint peer;
        public uint expected;
        public long lastRx;
    }

    static readonly object gate = new object();
    static byte[] helperId, K;
    static string code;
    static bool persist = true;
    static Socket sock;
    static Session cur, pending;
    static long lastReject;
    static volatile int leds;
    static volatile bool stop;
    static string logPath;
    static IPAddress manual;
    static long reportsApplied;

    // ------------------------------------------------------------ สถานะสำหรับหน้าต่าง
    public static string Code { get { return code.Substring(0, 4) + "-" + code.Substring(4); } }
    public static bool Connected { get { lock (gate) return cur != null; } }
    public static string PeerText { get { lock (gate) return cur == null ? "" : cur.peer.Address.ToString(); } }
    public static long Reports { get { return Interlocked.Read(ref reportsApplied); } }

    public static string PairedText
    {
        get
        {
            lock (gate)
            {
                if (paired.Count == 0) return "ยังไม่มีมือถือที่จับคู่แบบกดอนุญาต";
                List<string> n = new List<string>();
                foreach (Paired q in paired) n.Add(q.name);
                return "มือถือที่จับคู่แล้ว " + paired.Count + " เครื่อง: " + string.Join(", ", n.ToArray());
            }
        }
    }

    /// <summary>คำขอจับคู่ที่รอผู้ใช้ตัดสิน: คืน tag (ใช้ระบุคำขอ) หรือ null</summary>
    public static string PromptTag
    {
        get { lock (gate) return pairing != null && pairing.nA != null && pairing.state == 0 && !Expired(pairing) ? Hex(pairing.tag) : null; }
    }
    public static string PromptName { get { lock (gate) return pairing == null ? "" : pairing.name; } }
    public static string PromptNumber
    {
        get { lock (gate) { if (pairing == null || pairing.sas < 0) return ""; string s = pairing.sas.ToString("000000"); return s.Substring(0, 3) + " " + s.Substring(3); } }
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    static extern int GetCurrentPackageFullName(ref int length, StringBuilder name);

    /// <summary>กำลังถ่ายภาพหน้าต่างเพื่อทำภาพหน้าร้าน (ตั้ง PTW_SHOT) — ไม่แสดงชื่อและที่อยู่ของคอมพิวเตอร์เครื่องจริง</summary>
    static bool ShotMode { get { return !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("PTW_SHOT")); } }

    /// <summary>ติดตั้งจาก Microsoft Store (แพ็กเกจ MSIX) — มีงานเปิดเองตอนล็อกอิน</summary>
    public static bool IsPackaged
    {
        get
        {
            if (ShotMode && Environment.GetEnvironmentVariable("PTW_SHOT_AS_STORE") == "1") return true;   // ถ่ายภาพหน้าร้าน: จัดหน้าต่างแบบรุ่น Store
            try { int len = 0; return GetCurrentPackageFullName(ref len, null) != 15700; }   // 15700 = APPMODEL_ERROR_NO_PACKAGE
            catch (Exception) { return false; }
        }
    }

    // ------------------------------------------------------------ รหัสจับคู่
    static string ConfigPath()
    {
        string dir = Environment.GetEnvironmentVariable("PTW_CONFIG_DIR");   // ใช้ตอนทดสอบ: เก็บการตั้งค่าแยกจากของจริงของผู้ใช้
        if (string.IsNullOrEmpty(dir)) dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "PhoneTouchpad");
        Directory.CreateDirectory(dir);
        return Path.Combine(dir, "helper.dat");
    }

    static byte[] Rand(int n)
    {
        byte[] b = new byte[n];
        using (RandomNumberGenerator r = RandomNumberGenerator.Create()) r.GetBytes(b);
        return b;
    }

    static string Hex(byte[] b)
    {
        StringBuilder s = new StringBuilder();
        foreach (byte x in b) s.Append(x.ToString("x2"));
        return s.ToString();
    }

    static byte[] Unhex(string s)
    {
        byte[] b = new byte[s.Length / 2];
        for (int i = 0; i < b.Length; i++) b[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
        return b;
    }

    public static void NewCode()
    {
        lock (gate)
        {
            byte[] r = Rand(8);
            StringBuilder s = new StringBuilder();
            foreach (byte x in r) s.Append(ALPHABET[x & 31]);
            code = s.ToString();
            helperId = Rand(16);
            paired.Clear();          // รหัสใหม่ = ยกเลิกมือถือทุกเครื่องที่เคยจับคู่ ทั้งแบบรหัสและแบบกดอนุญาต
            pairing = null;
            SaveCode();
            try { SavePhones(); } catch (Exception) { }
            DeriveKey();
            if (cur != null) EndSession();
            pending = null;
        }
    }

    // ไฟล์ตั้งค่า (เข้ารหัสผูกกับบัญชี Windows ของผู้ใช้ด้วย DPAPI) มีสองไฟล์:
    //   helper.dat  helperId|รหัสจับคู่ — รูปแบบเดิมตั้งแต่รุ่นแรก ห้ามเพิ่มอะไร: โปรแกรมช่วยรุ่นเก่าที่อ่านไฟล์นี้ไม่ออก
    //               จะสร้างรหัสใหม่ทับ ทำให้มือถือทุกเครื่องต้องจับคู่ใหม่ (รุ่นเก่ากับรุ่นใหม่ใช้ไฟล์นี้ร่วมกันได้)
    //   phones.dat  บรรทัดแรก helperId · บรรทัดต่อไป P|กุญแจของมือถือ (hex)|ชื่อมือถือ (base64) — มือถือที่จับคู่แบบกดอนุญาต
    //               ผูกกับ helperId: ถ้า helperId เปลี่ยน (มีการสร้างรหัสใหม่ แม้จากรุ่นเก่า) รายชื่อนี้ถือว่าถูกยกเลิกไปด้วย
    static string PhonesPath()
    {
        return Path.Combine(Path.GetDirectoryName(ConfigPath()), "phones.dat");
    }

    static void SaveCode()
    {
        if (!persist) return;
        File.WriteAllBytes(ConfigPath(), ProtectedData.Protect(Encoding.UTF8.GetBytes(Hex(helperId) + "|" + code), null, DataProtectionScope.CurrentUser));
    }

    static void SavePhones()
    {
        if (!persist) return;
        StringBuilder b = new StringBuilder(Hex(helperId));
        foreach (Paired q in paired) b.Append("\nP|" + Hex(q.key) + "|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(q.name)));
        File.WriteAllBytes(PhonesPath(), ProtectedData.Protect(Encoding.UTF8.GetBytes(b.ToString()), null, DataProtectionScope.CurrentUser));
    }

    static void LoadPhones()
    {
        paired.Clear();
        try
        {
            string[] lines = Encoding.UTF8.GetString(
                ProtectedData.Unprotect(File.ReadAllBytes(PhonesPath()), null, DataProtectionScope.CurrentUser)).Split('\n');
            if (lines[0] != Hex(helperId)) return;   // รหัสถูกสร้างใหม่หลังบันทึกรายชื่อนี้ = ถูกยกเลิกไปแล้ว
            for (int i = 1; i < lines.Length; i++)
            {
                string[] q = lines[i].Split('|');
                if (q.Length != 3 || q[0] != "P" || q[1].Length != 64) continue;
                try
                {
                    Paired p = new Paired();
                    p.key = Unhex(q[1]);
                    p.name = Encoding.UTF8.GetString(Convert.FromBase64String(q[2]));
                    paired.Add(p);
                }
                catch (Exception) { }
            }
        }
        catch (Exception) { }   // ยังไม่มีไฟล์ = ยังไม่มีมือถือที่จับคู่แบบกดอนุญาต
    }

    static void LoadOrCreate(string testCode)
    {
        if (!string.IsNullOrEmpty(testCode))
        {
            persist = false;
            code = testCode.ToUpperInvariant().Replace("-", "");
            helperId = new byte[16];
            for (int i = 0; i < 16; i++) helperId[i] = (byte)(0xA0 + i);
            DeriveKey();
            return;
        }
        try
        {
            string[] parts = Encoding.UTF8.GetString(
                ProtectedData.Unprotect(File.ReadAllBytes(ConfigPath()), null, DataProtectionScope.CurrentUser)).Split('|');
            if (parts.Length == 2 && parts[0].Length == 32 && parts[1].Length == 8)
            {
                helperId = Unhex(parts[0]);
                code = parts[1];
                LoadPhones();
                DeriveKey();
                return;
            }
        }
        catch (Exception) { }
        NewCode();
    }

    static void DeriveKey()
    {
        using (Rfc2898DeriveBytes d = new Rfc2898DeriveBytes(Encoding.UTF8.GetBytes(code), helperId, 100000, HashAlgorithmName.SHA256))
            K = d.GetBytes(32);
    }

    // ------------------------------------------------------------ เข้ารหัส
    static byte[] Hmac(byte[] key, params byte[][] parts)
    {
        using (HMACSHA256 h = new HMACSHA256(key))
        {
            using (MemoryStream m = new MemoryStream())
            {
                foreach (byte[] p in parts) m.Write(p, 0, p.Length);
                return h.ComputeHash(m.ToArray());
            }
        }
    }

    static byte[] A(string s) { return Encoding.ASCII.GetBytes(s); }

    static byte[] Sub(byte[] b, int off, int n)
    {
        byte[] r = new byte[n];
        Buffer.BlockCopy(b, off, r, 0, n);
        return r;
    }

    static bool Same(byte[] a, int aoff, byte[] b, int boff, int n)
    {
        int diff = 0;
        for (int i = 0; i < n; i++) diff |= a[aoff + i] ^ b[boff + i];
        return diff == 0;
    }

    static void PutLong(byte[] b, int off, long v)
    {
        for (int i = 7; i >= 0; i--) { b[off + i] = (byte)v; v >>= 8; }
    }

    static long GetLong(byte[] b, int off)
    {
        long v = 0;
        for (int i = 0; i < 8; i++) v = (v << 8) | b[off + i];
        return v;
    }

    // AES-256-CTR: IV = ทิศ(1) sid(4) ตัวนับ(8) เลขบล็อก(3)
    static byte[] Crypt(byte[] key, int dir, byte[] sid, long ctr, byte[] data, int off, int n)
    {
        byte[] iv = new byte[16], ks = new byte[16], o = new byte[n];
        iv[0] = (byte)dir;
        Buffer.BlockCopy(sid, 0, iv, 1, 4);
        PutLong(iv, 5, ctr);
        using (Aes aes = Aes.Create())
        {
            aes.Mode = CipherMode.ECB;
            aes.Padding = PaddingMode.None;
            aes.Key = key;
            using (ICryptoTransform t = aes.CreateEncryptor())
            {
                for (int i = 0, blk = 0; i < n; i += 16, blk++)
                {
                    iv[13] = (byte)(blk >> 16); iv[14] = (byte)(blk >> 8); iv[15] = (byte)blk;
                    t.TransformBlock(iv, 0, 16, ks, 0);
                    for (int j = 0; j < 16 && i + j < n; j++) o[i + j] = (byte)(data[off + i + j] ^ ks[j]);
                }
            }
        }
        return o;
    }

    static byte[] Seal(Session s, int type, byte[] plain)
    {
        long ctr = ++s.txCtr;
        byte[] head = new byte[17];
        Buffer.BlockCopy(MAGIC, 0, head, 0, 4);
        head[4] = (byte)type;
        Buffer.BlockCopy(s.sid, 0, head, 5, 4);
        PutLong(head, 9, ctr);
        byte[] ct = Crypt(s.enc, 2, s.sid, ctr, plain, 0, plain.Length);
        byte[] mac = Hmac(s.mac, head, ct);
        byte[] p = new byte[17 + ct.Length + 16];
        Buffer.BlockCopy(head, 0, p, 0, 17);
        Buffer.BlockCopy(ct, 0, p, 17, ct.Length);
        Buffer.BlockCopy(mac, 0, p, 17 + ct.Length, 16);
        return p;
    }

    static byte[] Open(Session s, byte[] p, int len)
    {
        if (len < 33 || !Same(p, 5, s.sid, 0, 4)) return null;
        long ctr = GetLong(p, 9);
        if (ctr <= s.rxCtr) return null;
        byte[] head = Sub(p, 0, 17), ct = Sub(p, 17, len - 33);
        byte[] mac = Hmac(s.mac, head, ct);
        if (!Same(mac, 0, p, len - 16, 16)) return null;
        s.rxCtr = ctr;
        return Crypt(s.enc, 1, s.sid, ctr, ct, 0, ct.Length);
    }

    // ------------------------------------------------------------ เครือข่าย
    static void Send(byte[] p, IPEndPoint to)
    {
        try { sock.SendTo(p, to); }
        catch (Exception) { }
    }

    public static void SetManual(string ip)
    {
        IPAddress a;
        lock (gate) manual = IPAddress.TryParse((ip ?? "").Trim(), out a) && a.AddressFamily == AddressFamily.InterNetwork ? a : null;
    }

    public static string LocalAddresses()
    {
        List<string> l = new List<string>();
        try
        {
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up || ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                foreach (UnicastIPAddressInformation u in ni.GetIPProperties().UnicastAddresses)
                    if (u.Address.AddressFamily == AddressFamily.InterNetwork && !l.Contains(u.Address.ToString())) l.Add(u.Address.ToString());
            }
        }
        catch (Exception) { }
        return string.Join(", ", l.ToArray());
    }

    // ประกาศตัว: broadcast ทุกวงเครือข่าย + เกตเวย์ (ถ้าโน้ตบุ๊กต่อ Hotspot ของมือถือ เกตเวย์ก็คือมือถือ) + IP ที่ผู้ใช้ใส่เอง
    static void Beacon()
    {
        byte[] name = Encoding.UTF8.GetBytes(Environment.MachineName);
        if (name.Length > 60) name = Sub(name, 0, 60);
        byte[] p = new byte[23 + name.Length];
        Buffer.BlockCopy(MAGIC, 0, p, 0, 4);
        p[4] = T_BEACON;
        Buffer.BlockCopy(helperId, 0, p, 5, 16);
        p[21] = (byte)name.Length;
        Buffer.BlockCopy(name, 0, p, 22, name.Length);
        p[22 + name.Length] = CAP_TAP_PAIR;
        HashSet<string> seen = new HashSet<string>();
        List<IPAddress> to = new List<IPAddress>();
        to.Add(IPAddress.Broadcast);
        if (manual != null) to.Add(manual);
        try
        {
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up || ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                IPInterfaceProperties ip = ni.GetIPProperties();
                foreach (UnicastIPAddressInformation u in ip.UnicastAddresses)
                {
                    if (u.Address.AddressFamily != AddressFamily.InterNetwork || u.IPv4Mask == null) continue;
                    byte[] a = u.Address.GetAddressBytes(), m = u.IPv4Mask.GetAddressBytes();
                    if (m[0] == 0) continue;
                    for (int i = 0; i < 4; i++) a[i] = (byte)(a[i] | ~m[i]);
                    to.Add(new IPAddress(a));
                }
                foreach (GatewayIPAddressInformation g in ip.GatewayAddresses)
                    if (g.Address.AddressFamily == AddressFamily.InterNetwork) to.Add(g.Address);
            }
        }
        catch (Exception) { }
        foreach (IPAddress a in to)
            if (seen.Add(a.ToString())) Send(p, new IPEndPoint(a, PORT));
    }

    static void RxLoop()
    {
        byte[] buf = new byte[2048];
        while (!stop)
        {
            int n;
            EndPoint ep = new IPEndPoint(IPAddress.Any, 0);
            try { n = sock.ReceiveFrom(buf, ref ep); }
            catch (Exception) { if (stop) return; Thread.Sleep(20); continue; }
            if (n < 5 || !Same(buf, 0, MAGIC, 0, 4)) continue;
            try { lock (gate) Handle(buf, n, (IPEndPoint)ep); }
            catch (Exception) { }
        }
    }

    static void Handle(byte[] p, int n, IPEndPoint from)
    {
        long now = Environment.TickCount;
        if (p[4] == T_HELLO)
        {
            if (n != 53 || !Same(p, 5, helperId, 0, 16)) return;
            byte[] pn = Sub(p, 21, 16);
            // กุญแจที่ใช้ได้: กุญแจจากรหัสจับคู่ (แอปรุ่นเก่า) หรือกุญแจของมือถือที่จับคู่แบบกดอนุญาตไว้
            byte[] key = null;
            if (Same(Hmac(K, A("hello"), helperId, pn), 0, p, 37, 16)) key = K;
            else foreach (Paired q in paired) if (Same(Hmac(q.key, A("hello"), helperId, pn), 0, p, 37, 16)) { key = q.key; break; }
            if (key == null)
            {
                if (now - lastReject < 1000 && now >= lastReject) return;   // กันเดารหัสรัวๆ
                lastReject = now;
                byte[] r = new byte[37];
                Buffer.BlockCopy(MAGIC, 0, r, 0, 4);
                r[4] = T_REJECT;
                Buffer.BlockCopy(helperId, 0, r, 5, 16);
                Buffer.BlockCopy(pn, 0, r, 21, 16);
                Send(r, from);
                return;
            }
            byte[] pcn = Rand(16);
            byte[] s = Hmac(key, A("session"), pn, pcn);
            Session ses = new Session();
            ses.sid = Sub(pcn, 0, 4);
            ses.enc = Hmac(s, A("enc"));
            ses.mac = Hmac(s, A("mac"));
            ses.peer = from;
            ses.lastRx = now;
            pending = ses;   // ยังไม่แทนที่รอบปัจจุบันจนกว่าจะได้ข้อมูลที่ถูกต้องของรอบใหม่ (กันการส่ง HELLO เก่าซ้ำมาก่อกวน)
            byte[] w = new byte[53];
            Buffer.BlockCopy(MAGIC, 0, w, 0, 4);
            w[4] = T_WELCOME;
            Buffer.BlockCopy(pn, 0, w, 5, 16);
            Buffer.BlockCopy(pcn, 0, w, 21, 16);
            Buffer.BlockCopy(Hmac(key, A("welcome"), pn, pcn), 0, w, 37, 16);
            Send(w, from);
            return;
        }
        if (p[4] == T_PAIR1) { Pair1(p, n, from, now); return; }
        if (p[4] == T_PAIR3) { Pair3(p, n, from, now); return; }
        if (p[4] != T_DATA) return;
        Session t = null;
        byte[] plain = null;
        if (cur != null) { plain = Open(cur, p, n); if (plain != null) t = cur; }
        if (t == null && pending != null)
        {
            plain = Open(pending, p, n);
            if (plain != null)
            {
                if (cur != null) ReleaseAll();
                cur = t = pending;
                pending = null;
            }
        }
        if (t == null || plain.Length < 6) return;
        t.peer = from;
        t.lastRx = now;
        int flags = plain[0];
        uint first = ((uint)plain[1] << 24) | ((uint)plain[2] << 16) | ((uint)plain[3] << 8) | plain[4];
        int count = plain[5], pos = 6;
        if (count > 0 && first > t.expected)
        {
            ReleaseAll();           // มีรายงานหายไประหว่างทาง — ปล่อยปุ่มทั้งหมดก่อน กันปุ่มค้าง
            t.expected = first;
        }
        for (int i = 0; i < count && pos + 2 <= plain.Length; i++)
        {
            int id = plain[pos], len = plain[pos + 1];
            if (pos + 2 + len > plain.Length) break;
            if (first + (uint)i == t.expected)
            {
                Apply(id, plain, pos + 2, len, (flags & 2) != 0);
                t.expected++;
            }
            pos += 2 + len;
        }
        byte[] ack = new byte[5];
        ack[0] = (byte)(t.expected >> 24); ack[1] = (byte)(t.expected >> 16); ack[2] = (byte)(t.expected >> 8); ack[3] = (byte)t.expected;
        ack[4] = (byte)leds;
        Send(Seal(t, T_ACK, ack), from);
        if ((flags & 1) != 0) EndSession();
    }

    static void EndSession()
    {
        ReleaseAll();
        cur = null;
    }

    // ------------------------------------------------------------ จับคู่แบบกดอนุญาต
    static byte[] Sha(params byte[][] parts)
    {
        using (SHA256 h = SHA256.Create())
        using (MemoryStream m = new MemoryStream())
        {
            foreach (byte[] p in parts) m.Write(p, 0, p.Length);
            return h.ComputeHash(m.ToArray());
        }
    }

    static bool Expired(Pairing g)
    {
        long age = Environment.TickCount - g.created;
        return g.state == 0 && (age > 120000 || age < 0);
    }

    static void Pair1(byte[] p, int n, IPEndPoint from, long now)
    {
        if (n < 87 || !Same(p, 5, helperId, 0, 16) || p[21] != 4) return;
        int nl = p[86];
        if (n < 87 + nl) return;
        byte[] pkA = Sub(p, 21, 65);
        if (pairing != null && Same(pairing.pkA, 0, pkA, 0, 65)) { pairing.from = from; SendPair2(); return; }   // PAIR2 หาย มือถือส่งซ้ำ
        if (pairing != null && pairing.state == 0 && !Expired(pairing)) return;   // กำลังถามผู้ใช้เรื่องมือถืออีกเครื่อง
        Refused rf;
        if (refused.TryGetValue(from.Address.ToString(), out rf) && now < rf.until && rf.until - now <= 600000) return;
        if (now - lastPairStart < 2000 && now >= lastPairStart) return;           // กันการขอรัวๆ
        lastPairStart = now;
        StringBuilder name = new StringBuilder();
        foreach (char c in Encoding.UTF8.GetString(p, 87, nl)) if (!char.IsControl(c) && name.Length < 40) name.Append(c);
        Pairing g = new Pairing();
        g.pkA = pkA;
        g.tag = Sub(Sha(pkA), 0, 16);
        g.name = name.Length > 0 ? name.ToString() : "มือถือ";
        g.from = from;
        g.created = now;
        try
        {
            using (ECDiffieHellmanCng e = new ECDiffieHellmanCng(256))
            {
                e.KeyDerivationFunction = ECDiffieHellmanKeyDerivationFunction.Hash;
                e.HashAlgorithm = CngAlgorithm.Sha256;           // ผลลัพธ์ = SHA256(Z) ตรงกับฝั่งแอป
                byte[] blob = new byte[72];                        // BCRYPT_ECCPUBLIC_BLOB: "ECK1" · 32 · X · Y
                blob[0] = 0x45; blob[1] = 0x43; blob[2] = 0x4B; blob[3] = 0x31; blob[4] = 32;
                Buffer.BlockCopy(pkA, 1, blob, 8, 64);
                using (CngKey peer = CngKey.Import(blob, CngKeyBlobFormat.EccPublicBlob))   // จุดที่ไม่อยู่บนเส้นโค้งจะ import ไม่ผ่าน
                    g.zh = e.DeriveKeyMaterial(peer);
                byte[] mine = e.PublicKey.ToByteArray();
                g.pkB = new byte[65];
                g.pkB[0] = 4;
                Buffer.BlockCopy(mine, 8, g.pkB, 1, 64);
            }
        }
        catch (Exception) { return; }
        g.nB = Rand(16);
        g.commit = Sub(Sha(A("ptw-commit"), g.pkB, g.pkA, g.nB), 0, 16);
        pairing = g;
        SendPair2();
    }

    static void SendPair2()
    {
        byte[] r = new byte[102];
        Buffer.BlockCopy(MAGIC, 0, r, 0, 4);
        r[4] = T_PAIR2;
        Buffer.BlockCopy(helperId, 0, r, 5, 16);
        Buffer.BlockCopy(pairing.pkB, 0, r, 21, 65);
        Buffer.BlockCopy(pairing.commit, 0, r, 86, 16);
        Send(r, pairing.from);
    }

    static void Pair3(byte[] p, int n, IPEndPoint from, long now)
    {
        Pairing g = pairing;
        if (n != 53 || g == null || !Same(p, 5, helperId, 0, 16) || !Same(p, 21, g.tag, 0, 16) || Expired(g)) return;
        if (g.nA == null)
        {
            g.nA = Sub(p, 37, 16);
            g.K = Hmac(g.zh, A("ptw-pairkey"), g.pkA, g.pkB, g.nA, g.nB);
            byte[] h = Sha(A("ptw-sas"), g.pkA, g.pkB, g.nA, g.nB);
            g.sas = (int)((((uint)h[0] << 24) | ((uint)h[1] << 16) | ((uint)h[2] << 8) | h[3]) % 1000000u);
            if (autoAllow) Decide(g, true);
        }
        else if (!Same(p, 37, g.nA, 0, 16)) return;
        g.from = from;
        SendPair4(g);
    }

    static void SendPair4(Pairing g)
    {
        byte[] r = new byte[70];
        Buffer.BlockCopy(MAGIC, 0, r, 0, 4);
        r[4] = T_PAIR4;
        Buffer.BlockCopy(helperId, 0, r, 5, 16);
        Buffer.BlockCopy(g.tag, 0, r, 21, 16);
        Buffer.BlockCopy(g.nB, 0, r, 37, 16);
        r[53] = (byte)g.state;
        Buffer.BlockCopy(Hmac(g.K, A("ptw-paired"), new byte[] { (byte)g.state }, g.tag), 0, r, 54, 16);
        Send(r, g.from);
    }

    static void Decide(Pairing g, bool allow)
    {
        if (g.state != 0) return;
        g.state = allow ? 1 : 2;
        if (allow)
        {
            Paired q = new Paired();
            q.key = g.K;
            q.name = g.name;
            paired.Add(q);
            while (paired.Count > MAX_PAIRED) paired.RemoveAt(0);
            try { SavePhones(); } catch (Exception) { }
        }
        SendPair4(g);
    }

    /// <summary>ผู้ใช้กดอนุญาต/ไม่อนุญาตในหน้าต่างถาม</summary>
    public static void Decide(string tag, bool allow)
    {
        lock (gate)
        {
            if (pairing == null || pairing.nA == null || Hex(pairing.tag) != tag || pairing.state != 0) return;
            string ip = pairing.from.Address.ToString();
            if (allow) refused.Remove(ip);
            else
            {
                Refused rf;
                if (!refused.TryGetValue(ip, out rf)) refused[ip] = rf = new Refused();
                rf.count++;
                long wait = 10000L << (2 * Math.Min(rf.count - 1, 3));   // 10 วิ × 4^(ครั้งที่ - 1)
                rf.until = Environment.TickCount + Math.Min(wait, 600000L);
            }
            Decide(pairing, allow);
        }
    }

    static void TimerLoop()
    {
        int tick = 0;
        while (!stop)
        {
            Thread.Sleep(100);
            tick++;
            lock (gate)
            {
                long now = Environment.TickCount;
                if (cur != null && (now - cur.lastRx > 3000 || now < cur.lastRx)) EndSession();
                if (cur == null && tick % 10 == 0) Beacon();
            }
        }
    }

    // ------------------------------------------------------------ สั่งเมาส์/คีย์บอร์ดของ Windows
    [StructLayout(LayoutKind.Sequential)]
    struct MOUSEINPUT { public int dx, dy, mouseData, dwFlags, time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Sequential)]
    struct KEYBDINPUT { public ushort wVk, wScan; public int dwFlags, time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Explicit)]
    struct InputUnion { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
    [StructLayout(LayoutKind.Sequential)]
    struct INPUT { public int type; public InputUnion u; }

    [DllImport("user32.dll", SetLastError = true)]
    static extern uint SendInput(uint n, INPUT[] inputs, int size);
    [DllImport("user32.dll")]
    static extern short GetKeyState(int vk);

    static int buttons, mods;
    static readonly bool[] down = new bool[256];
    static readonly ushort[] SCAN = BuildScan();

    // รหัสปุ่ม HID -> scan code ของ Windows (0xE0xx = ปุ่มกลุ่มขยาย) — ส่งเป็น scan code เหมือนคีย์บอร์ดจริง
    // ตัวอักษรที่ออกจึงขึ้นกับภาษาของ Windows ตอนนั้น เหมือนตอนใช้ผ่าน Bluetooth ทุกประการ
    static ushort[] BuildScan()
    {
        ushort[] t = new ushort[256];
        byte[] letters = { 0x1E, 0x30, 0x2E, 0x20, 0x12, 0x21, 0x22, 0x23, 0x17, 0x24, 0x25, 0x26, 0x32, 0x31, 0x18, 0x19, 0x10, 0x13, 0x1F, 0x14, 0x16, 0x2F, 0x11, 0x2D, 0x15, 0x2C };
        for (int i = 0; i < 26; i++) t[0x04 + i] = letters[i];
        for (int i = 0; i < 10; i++) t[0x1E + i] = (ushort)(0x02 + i);
        ushort[] a = { 0x1C, 0x01, 0x0E, 0x0F, 0x39, 0x0C, 0x0D, 0x1A, 0x1B, 0x2B, 0x2B, 0x27, 0x28, 0x29, 0x33, 0x34, 0x35, 0x3A };
        for (int i = 0; i < a.Length; i++) t[0x28 + i] = a[i];
        for (int i = 0; i < 10; i++) t[0x3A + i] = (ushort)(0x3B + i);   // F1-F10
        t[0x44] = 0x57; t[0x45] = 0x58;                                    // F11 F12
        t[0x46] = 0xE037; t[0x47] = 0x46;                                  // PrtSc ScrollLock
        ushort[] nav = { 0xE052, 0xE047, 0xE049, 0xE053, 0xE04F, 0xE051, 0xE04D, 0xE04B, 0xE050, 0xE048 };
        for (int i = 0; i < nav.Length; i++) t[0x49 + i] = nav[i];         // Ins Home PgUp Del End PgDn Right Left Down Up
        t[0x53] = 0xE045; t[0x54] = 0xE035; t[0x55] = 0x37; t[0x56] = 0x4A; t[0x57] = 0x4E; t[0x58] = 0xE01C;
        ushort[] kp = { 0x4F, 0x50, 0x51, 0x4B, 0x4C, 0x4D, 0x47, 0x48, 0x49, 0x52, 0x53 };
        for (int i = 0; i < kp.Length; i++) t[0x59 + i] = kp[i];           // แป้นตัวเลข 1-9 0 .
        t[0x64] = 0x56; t[0x65] = 0xE05D;
        return t;
    }

    static readonly ushort[] MODSCAN = { 0x1D, 0x2A, 0x38, 0xE05B, 0xE01D, 0x36, 0xE038, 0xE05C };

    static INPUT Key(ushort sc, bool up)
    {
        INPUT i = new INPUT();
        i.type = 1;
        i.u.ki.wScan = (ushort)(sc & 0xFF);
        i.u.ki.dwFlags = 0x0008 | ((sc & 0xE000) != 0 ? 0x0001 : 0) | (up ? 0x0002 : 0);
        return i;
    }

    static INPUT Mouse(int flags, int dx, int dy, int data)
    {
        INPUT i = new INPUT();
        i.type = 0;
        i.u.mi.dwFlags = flags;
        i.u.mi.dx = dx;
        i.u.mi.dy = dy;
        i.u.mi.mouseData = data;
        return i;
    }

    static void Inject(List<INPUT> l)
    {
        if (l.Count == 0 || logPath != null) return;
        SendInput((uint)l.Count, l.ToArray(), Marshal.SizeOf(typeof(INPUT)));
    }

    static void Log(string s)
    {
        if (logPath == null) return;
        try { File.AppendAllText(logPath, s + "\r\n"); }
        catch (Exception) { }
    }

    static void Apply(int id, byte[] d, int off, int len, bool hiRes)
    {
        Interlocked.Increment(ref reportsApplied);
        List<INPUT> l = new List<INPUT>();
        if (id == 2 && len >= 5)
        {
            int b = d[off] & 7, dx = (sbyte)d[off + 1], dy = (sbyte)d[off + 2], w = (sbyte)d[off + 3], pan = (sbyte)d[off + 4];
            Log("M " + b + " " + dx + " " + dy + " " + w + " " + pan);
            SetButtons(b, l);
            if (dx != 0 || dy != 0) l.Add(Mouse(0x0001, dx, dy, 0));
            if (w != 0) l.Add(Mouse(0x0800, 0, 0, hiRes ? w : w * 120));
            if (pan != 0) l.Add(Mouse(0x1000, 0, 0, hiRes ? pan : pan * 120));
        }
        else if (id == 1 && len >= 8)
        {
            Log("K " + BitConverter.ToString(d, off, 8));
            bool[] want = new bool[256];
            for (int i = 2; i < 8; i++) want[d[off + i]] = true;
            want[0] = false;
            int m = d[off];
            for (int k = 1; k < 256; k++) if (down[k] && !want[k]) { down[k] = false; if (SCAN[k] != 0) l.Add(Key(SCAN[k], true)); }
            for (int i = 0; i < 8; i++) if ((mods & (1 << i)) != 0 && (m & (1 << i)) == 0) l.Add(Key(MODSCAN[i], true));
            for (int i = 0; i < 8; i++) if ((mods & (1 << i)) == 0 && (m & (1 << i)) != 0) l.Add(Key(MODSCAN[i], false));
            for (int k = 1; k < 256; k++) if (!down[k] && want[k]) { down[k] = true; if (SCAN[k] != 0) l.Add(Key(SCAN[k], false)); }
            mods = m;
        }
        Inject(l);
    }

    static void SetButtons(int b, List<INPUT> l)
    {
        int[] dn = { 0x0002, 0x0008, 0x0020 }, up = { 0x0004, 0x0010, 0x0040 };
        for (int i = 0; i < 3; i++)
        {
            bool was = (buttons & (1 << i)) != 0, now = (b & (1 << i)) != 0;
            if (was != now) l.Add(Mouse(now ? dn[i] : up[i], 0, 0, 0));
        }
        buttons = b;
    }

    static void ReleaseAll()
    {
        List<INPUT> l = new List<INPUT>();
        for (int k = 1; k < 256; k++) if (down[k]) { down[k] = false; if (SCAN[k] != 0) l.Add(Key(SCAN[k], true)); }
        for (int i = 0; i < 8; i++) if ((mods & (1 << i)) != 0) l.Add(Key(MODSCAN[i], true));
        mods = 0;
        SetButtons(0, l);
        if (l.Count > 0) Log("RELEASE-ALL");
        Inject(l);
    }

    public static void PollLeds()
    {
        leds = ((GetKeyState(0x90) & 1) != 0 ? 1 : 0) | ((GetKeyState(0x14) & 1) != 0 ? 2 : 0) | ((GetKeyState(0x91) & 1) != 0 ? 4 : 0);
    }

    // ------------------------------------------------------------ เริ่ม/หยุด
    static Mutex instance;
    static EventWaitHandle showSignal;

    [DllImport("user32.dll")]
    static extern bool AllowSetForegroundWindow(int processId);
    [DllImport("user32.dll")]
    static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")]
    static extern bool ShowWindowAsync(IntPtr hwnd, int cmd);

    /// <summary>
    /// เปิดได้ทีละตัว: ถ้ามีตัวอื่นทำงานอยู่แล้ว สั่งให้ตัวนั้นแสดงหน้าต่างแล้วคืน false
    /// test = เปิดเพื่อทดสอบ (รหัสทดสอบ/โฟลเดอร์ตั้งค่าแยก) ใช้ล็อกคนละชื่อ จึงไม่ชนกับโปรแกรมช่วยตัวจริงของผู้ใช้
    /// </summary>
    public static bool ClaimInstance(bool test)
    {
        string name = "Local\\PhoneTouchpadWiFiHelper" + (test ? ".Test" : "");   // ชื่อเดียวกับที่ exe รุ่น 1.0.1 ใช้กันเปิดซ้ำ
        bool first;
        instance = new Mutex(true, name, out first);
        showSignal = new EventWaitHandle(false, EventResetMode.AutoReset, name + ".Show");
        if (!first)
        {
            if (StartHidden || StartedAtLogon()) return false;   // ถูกเปิดเองตอนล็อกอินแต่มีอีกตัวทำงานอยู่แล้ว: จบเงียบๆ ไม่เรียกหน้าต่างขึ้นมา
            try { AllowSetForegroundWindow(-1); }   // ตัวที่เพิ่งถูกเปิด (ตัวนี้) มีสิทธิ์ขึ้นหน้าจอ — ยกให้ตัวที่ทำงานอยู่
            catch (Exception) { }
            showSignal.Set();
            // ตัวที่ถือล็อกอาจเป็นรุ่น 1.0.1 ซึ่งไม่ฟังสัญญาณนี้ — ดึงหน้าต่างของมันขึ้นมาให้เห็น ดีกว่าเปิดแล้วเงียบหาย
            if (!test)
                foreach (Process p in FindOldCopies())
                {
                    try { ShowWindowAsync(p.MainWindowHandle, 9); SetForegroundWindow(p.MainWindowHandle); }   // 9 = SW_RESTORE
                    catch (Exception) { }
                }
        }
        return first;
    }

    /// <summary>
    /// ถูกเปิดโดยงานเปิดเองตอนล็อกอินของแพ็กเกจ Microsoft Store: งานนั้นชี้ไปที่สำเนาของโปรแกรมที่ชื่อลงท้ายด้วย .Startup.exe
    /// (ดู win/package/AppxManifest.xml) จึงรู้ได้แน่นอนโดยไม่ต้องเดาจากเวลา — เปิดจากเมนู Start ใช้ชื่อปกติ
    /// </summary>
    static bool StartedAtLogon()
    {
        try { return Path.GetFileNameWithoutExtension(Application.ExecutablePath).EndsWith(".Startup", StringComparison.OrdinalIgnoreCase); }
        catch (Exception) { return false; }
    }

    // ------------------------------------------------------------ เปิดเองตอนล็อกอิน สำหรับแบบที่ไม่ได้ติดตั้งจาก Microsoft Store
    // รุ่น Store ใช้งานเปิดเองของแพ็กเกจ (ปิดได้ที่ การตั้งค่า > แอป > เริ่มต้นระบบ) — แบบสคริปต์ใช้รายการ Run ของผู้ใช้ปัจจุบัน
    // ในรีจิสทรี ไม่ต้องใช้สิทธิ์ผู้ดูแลระบบ และเห็น/ปิดได้ใน Task Manager > แอปเริ่มต้นระบบ เช่นกัน
    const string RUN_KEY = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    static string runName = "PhoneTouchpadHelper";
    /// <summary>ที่อยู่ของไฟล์ .ps1 ที่กำลังรัน (สคริปต์ตั้งให้) — ว่าง = รันจาก exe</summary>
    public static string ScriptPath;
    /// <summary>ถูกเปิดโดยรายการเปิดเองตอนล็อกอิน (-Startup): ไม่เด้งหน้าต่าง</summary>
    public static bool StartHidden;

    static string RunCommand()
    {
        if (!string.IsNullOrEmpty(ScriptPath))
            return "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + ScriptPath + "\" -Startup";
        return "\"" + Application.ExecutablePath + "\" -Startup";
    }

    /// <summary>มีรายการเปิดเองตอนล็อกอินอยู่หรือไม่ / สร้างหรือลบรายการนั้น</summary>
    public static bool AutoStart
    {
        get
        {
            try { using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RUN_KEY)) return k != null && k.GetValue(runName) != null; }
            catch (Exception) { return false; }
        }
        set
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.CreateSubKey(RUN_KEY))
                {
                    if (value) k.SetValue(runName, RunCommand());
                    else k.DeleteValue(runName, false);
                }
            }
            catch (Exception) { }
        }
    }

    static string AutoStartChoicePath()
    {
        return Path.Combine(Path.GetDirectoryName(ConfigPath()), "autostart.txt");
    }

    /// <summary>
    /// ตอนเปิดโปรแกรม: ครั้งแรกเปิดใช้การเปิดเองให้เลย (ผู้ใช้เห็นและเอาออกได้จากช่องติ๊กในหน้าต่าง) ครั้งต่อไปทำตามที่ผู้ใช้เลือกไว้
    /// ถ้าเลือกเปิดไว้ จะเขียนรายการใหม่ทุกครั้ง เผื่อโฟลเดอร์ของโปรแกรมถูกย้าย
    /// </summary>
    static void InitAutoStart()
    {
        string choice = null;
        try { choice = File.ReadAllText(AutoStartChoicePath()).Trim(); }
        catch (Exception) { }
        if (choice == "off") return;
        SetAutoStartChoice(true);
    }

    static void SetAutoStartChoice(bool on)
    {
        try { File.WriteAllText(AutoStartChoicePath(), on ? "on" : "off"); }
        catch (Exception) { }
        AutoStart = on;
    }

    // ชื่อหน้าต่างของโปรแกรมช่วยก่อนรุ่น 1.0.2 (ไม่มีตัวกันเปิดซ้ำ): ถ้ายังเปิดอยู่ (เช่นแบบสคริปต์ที่เปิดจาก .bat) จะทำงานซ้อนกับตัวนี้ด้วยรหัสเดียวกัน
    const string OLD_TITLE = "Phone Touchpad - Wi-Fi";
    static volatile int oldCopies;
    static volatile bool windowShown = true;

    static List<Process> FindOldCopies()
    {
        List<Process> l = new List<Process>();
        try
        {
            Process self = Process.GetCurrentProcess();
            foreach (Process p in Process.GetProcesses())
            {
                try { if (p.Id != self.Id && p.SessionId == self.SessionId && p.MainWindowTitle == OLD_TITLE) l.Add(p); }
                catch (Exception) { }
            }
        }
        catch (Exception) { }
        return l;
    }

    /// <summary>สั่งปิดหน้าต่างของรุ่นเก่า (เหมือนผู้ใช้กดปุ่มปิดเอง) — เรียกเมื่อผู้ใช้กดปุ่มในหน้าต่างเท่านั้น</summary>
    static void CloseOldCopies()
    {
        foreach (Process p in FindOldCopies())
        {
            try { p.CloseMainWindow(); }
            catch (Exception) { }
        }
    }

    public static void Start(string testCode, string log, bool allowAll)
    {
        // อนุญาตเองได้เฉพาะตอนทดสอบ (รหัสทดสอบ หรือโฟลเดอร์ตั้งค่าแยก) — ไม่มีทางเปิดกับการจับคู่จริงของผู้ใช้
        testMode = !string.IsNullOrEmpty(testCode) || !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("PTW_CONFIG_DIR"));
        autoAllow = allowAll && testMode;
        logPath = string.IsNullOrEmpty(log) ? null : log;
        LoadOrCreate(testCode);
        sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        sock.EnableBroadcast = true;
        sock.Bind(new IPEndPoint(IPAddress.Any, 0));
        // ไม่ให้ ICMP "ปลายทางไม่รับ" (เช่นเกตเวย์ที่ไม่ใช่มือถือ) ทำให้การรับล้ม
        try { sock.IOControl(unchecked((int)0x9800000C), new byte[] { 0, 0, 0, 0 }, null); }
        catch (Exception) { }
        Thread rx = new Thread(RxLoop); rx.IsBackground = true; rx.Start();
        Thread tm = new Thread(TimerLoop); tm.IsBackground = true; tm.Start();
    }

    public static void Stop()
    {
        lock (gate) { if (cur != null) EndSession(); }
        stop = true;
        try { sock.Close(); }
        catch (Exception) { }
    }

    // ------------------------------------------------------------ หน้าต่าง (ธีมสว่าง) + ไอคอนข้างนาฬิกา
    static Form mainForm;
    static NotifyIcon tray;
    static bool quitting, balloonShown;

    static void ShowMain()
    {
        mainForm.Show();
        if (mainForm.WindowState == FormWindowState.Minimized) mainForm.WindowState = FormWindowState.Normal;
        mainForm.Activate();
        try { SetForegroundWindow(mainForm.Handle); }
        catch (Exception) { }
    }

    static void Quit(ApplicationContext ctx)
    {
        quitting = true;
        tray.Visible = false;
        Stop();
        ctx.ExitThread();
    }

    static Label MakeLabel(string text, int x, int y, int w, int h)
    {
        Label l = new Label();
        l.Text = text;
        l.SetBounds(x, y, w, h);
        return l;
    }

    public static void RunUi()
    {
        Application.EnableVisualStyles();
        Color blue = Color.FromArgb(57, 73, 171), grey = Color.FromArgb(95, 99, 104);
        Icon appIcon = null;
        try { appIcon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); }
        catch (Exception) { }

        Form f = new Form();
        mainForm = f;
        f.Text = "Phone Touchpad - โปรแกรมช่วย";   // ต้องไม่ซ้ำกับ OLD_TITLE
        if (appIcon != null) f.Icon = appIcon;
        f.BackColor = Color.White;
        f.ForeColor = Color.FromArgb(32, 33, 36);
        f.Font = new Font("Leelawadee UI", 10f);
        f.FormBorderStyle = FormBorderStyle.FixedSingle;
        f.MaximizeBox = false;
        f.StartPosition = FormStartPosition.CenterScreen;
        f.ClientSize = new Size(460, 470);

        Label title = MakeLabel("Phone Touchpad  ·  โปรแกรมช่วย", 20, 16, 420, 30);
        title.Font = new Font("Leelawadee UI", 14f, FontStyle.Bold);
        title.ForeColor = blue;

        Label status = MakeLabel("", 20, 52, 420, 26);
        status.Font = new Font("Leelawadee UI", 11f, FontStyle.Bold);

        Label how = MakeLabel("วิธีเชื่อมต่อ: ให้มือถือกับคอมพิวเตอร์อยู่ Wi-Fi เดียวกัน (หรือคอมต่อ Hotspot ของมือถือ) "
            + "เปิดแอป Phone Touchpad บนมือถือแล้วแตะ \"จับคู่\" จากนั้นกด \"อนุญาต\" ในหน้าต่างที่เด้งขึ้นบนเครื่องนี้ ครั้งแรกครั้งเดียว", 20, 86, 420, 66);
        how.BackColor = Color.FromArgb(240, 242, 250);
        how.Padding = new Padding(8, 6, 8, 6);

        Label pairedLabel = MakeLabel("", 20, 160, 420, 40);
        pairedLabel.ForeColor = grey;

        Label keep = MakeLabel(IsPackaged
            ? "ปิดหน้าต่างนี้ได้ โปรแกรมยังทำงานอยู่ที่ไอคอนข้างนาฬิกา และเปิดเองทุกครั้งที่เปิดเครื่อง (ปิดได้ที่ การตั้งค่า > แอป > เริ่มต้นระบบ)"
            : "ปิดหน้าต่างนี้ได้ โปรแกรมยังทำงานอยู่ที่ไอคอนข้างนาฬิกา (คลิกขวาที่ไอคอน > ออก เพื่อหยุด)", 20, 204, 420, 44);
        keep.ForeColor = grey;

        // แบบที่ไม่ได้ติดตั้งจาก Store: ช่องติ๊กเปิดเองตอนเปิดเครื่อง (รุ่น Store ใช้หน้า การตั้งค่า > แอป > เริ่มต้นระบบ ของ Windows)
        CheckBox auto = new CheckBox();
        auto.Text = "เปิดเองเมื่อเปิดเครื่อง (ไม่เด้งหน้าต่าง อยู่ที่ไอคอนข้างนาฬิกา)";
        auto.SetBounds(20, 250, 420, 24);
        auto.Visible = !IsPackaged;
        auto.Enabled = !testMode;      // ตอนทดสอบไม่แตะรายการเปิดเองของผู้ใช้
        if (!IsPackaged && !testMode)
        {
            InitAutoStart();
            auto.Checked = AutoStart;
            auto.CheckedChanged += delegate { SetAutoStartChoice(auto.Checked); };
        }
        int lower = IsPackaged ? 0 : 28;   // ส่วนล่างของหน้าต่างเลื่อนลงเท่าความสูงของช่องติ๊ก

        Label codeTitle = MakeLabel("แอปรุ่นก่อน 1.24 ใช้รหัสจับคู่นี้แทน:", 20, 256, 250, 22);
        codeTitle.ForeColor = grey;
        Label codeLabel = MakeLabel(Code, 270, 252, 170, 30);
        codeLabel.Font = new Font("Consolas", 15f, FontStyle.Bold);
        codeLabel.TextAlign = ContentAlignment.MiddleRight;

        Label info = MakeLabel("", 20, 290, 420, 40);
        info.ForeColor = grey;

        Label l2 = MakeLabel("IP ของมือถือ (ใส่เฉพาะเมื่อแอปหาคอมพิวเตอร์ไม่เจอ)", 20, 338, 420, 22);
        TextBox ipBox = new TextBox();
        ipBox.SetBounds(20, 362, 200, 26);
        ipBox.TextChanged += delegate { SetManual(ipBox.Text); };

        Button renew = new Button();
        renew.Text = "ยกเลิกการจับคู่ทั้งหมด";
        renew.FlatStyle = FlatStyle.System;
        renew.SetBounds(20, 414, 190, 32);
        renew.Click += delegate
        {
            if (MessageBox.Show(f, "ยกเลิกการจับคู่มือถือทุกเครื่องและสร้างรหัสใหม่? มือถือทุกเครื่องต้องจับคู่ใหม่", "Phone Touchpad",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                NewCode();
                codeLabel.Text = Code;
            }
        };

        foreach (Control c in new Control[] { codeTitle, codeLabel, info, l2, ipBox, renew }) c.Top += lower;
        f.ClientSize = new Size(460, 470 + lower);

        Panel warn = new Panel();
        warn.SetBounds(20, 84, 420, 54);
        warn.BackColor = Color.FromArgb(255, 244, 229);
        warn.Visible = false;
        Label warnText = MakeLabel("", 8, 6, 292, 42);
        warnText.ForeColor = Color.FromArgb(138, 82, 0);
        Button warnClose = new Button();
        warnClose.Text = "ปิดรุ่นเก่า";
        warnClose.FlatStyle = FlatStyle.System;
        warnClose.SetBounds(306, 11, 106, 32);
        warnClose.Click += delegate { CloseOldCopies(); };
        warn.Controls.Add(warnText);
        warn.Controls.Add(warnClose);
        Control[] below = { how, pairedLabel, keep, auto, codeTitle, codeLabel, info, l2, ipBox, renew };
        bool warnOn = false, warnBalloon = false;
        Action<int> setWarn = delegate (int count)
        {
            bool on = count > 0;
            if (on) warnText.Text = "โปรแกรมช่วยรุ่นเก่ายังเปิดอยู่อีก " + count + " ตัว และทำงานซ้อนกับตัวนี้ ควรปิดรุ่นเก่า";
            if (on == warnOn) return;
            warnOn = on;
            int d = on ? 62 : -62;
            foreach (Control c in below) c.Top += d;
            f.ClientSize = new Size(f.ClientSize.Width, f.ClientSize.Height + d);
            warn.Visible = on;
        };

        f.Controls.AddRange(new Control[] { title, status, warn, how, pairedLabel, keep, auto, codeTitle, codeLabel, info, l2, ipBox, renew });

        ApplicationContext ctx = new ApplicationContext();
        tray = new NotifyIcon();
        tray.Icon = appIcon ?? SystemIcons.Application;
        tray.Text = "Phone Touchpad";
        ContextMenuStrip menu = new ContextMenuStrip();
        menu.Items.Add("เปิดหน้าต่าง", null, delegate { ShowMain(); });
        menu.Items.Add("ออก (หยุดรับคำสั่งจากมือถือ)", null, delegate { Quit(ctx); });
        tray.ContextMenuStrip = menu;
        tray.DoubleClick += delegate { ShowMain(); };
        tray.Visible = true;

        f.FormClosing += delegate (object s, FormClosingEventArgs e)
        {
            if (quitting || e.CloseReason != CloseReason.UserClosing) return;
            e.Cancel = true;
            f.Hide();
            if (!balloonShown)
            {
                balloonShown = true;
                tray.ShowBalloonTip(5000, "Phone Touchpad ยังทำงานอยู่", "อยู่ที่ไอคอนข้างนาฬิกา คลิกขวาที่ไอคอนเพื่อออก", ToolTipIcon.Info);
            }
        };

        // เปิดโปรแกรมซ้ำ (เช่นจากเมนู Start) = แสดงหน้าต่างของตัวที่ทำงานอยู่
        if (showSignal != null)
        {
            Thread w = new Thread(delegate ()
            {
                while (!stop)
                {
                    if (!showSignal.WaitOne(1000)) continue;
                    try { f.BeginInvoke((MethodInvoker)ShowMain); }
                    catch (Exception) { }
                }
            });
            w.IsBackground = true;
            w.Start();
        }

        Thread scan = new Thread(delegate ()
        {
            while (!stop)
            {
                oldCopies = FindOldCopies().Count;
                // ไล่ดูทุกโปรเซสมีต้นทุน: เปิดหน้าต่างอยู่ดูทุก 5 วินาที ซ่อนอยู่ที่ไอคอนข้างนาฬิกาดูทุก 1 นาที
                for (int i = 0; i < 600 && !stop; i++)
                {
                    if (windowShown && i >= 50) break;
                    Thread.Sleep(100);
                }
            }
        });
        scan.IsBackground = true;
        scan.Start();

        // หน้าต่างถามเมื่อมีมือถือขอจับคู่
        Form ask = null;
        string askTag = null;
        Action showAsk = delegate
        {
            string tag = PromptTag;
            if (ask != null && tag != askTag) { Form old = ask; ask = null; old.Close(); }
            if (tag == null || ask != null) return;
            askTag = tag;
            Form d = new Form();
            d.Text = "Phone Touchpad - ขอจับคู่";
            if (appIcon != null) d.Icon = appIcon;
            d.BackColor = Color.White;
            d.Font = f.Font;
            d.FormBorderStyle = FormBorderStyle.FixedDialog;
            d.MaximizeBox = false;
            d.MinimizeBox = false;
            d.TopMost = true;
            d.StartPosition = FormStartPosition.CenterScreen;
            d.ClientSize = new Size(420, 270);
            Label q = MakeLabel("มือถือ \"" + PromptName + "\" ขอเชื่อมต่อกับคอมพิวเตอร์เครื่องนี้", 20, 16, 380, 46);
            q.Font = new Font("Leelawadee UI", 11f, FontStyle.Bold);
            Label num = MakeLabel(PromptNumber, 20, 66, 380, 60);
            num.Font = new Font("Consolas", 30f, FontStyle.Bold);
            num.ForeColor = blue;
            num.TextAlign = ContentAlignment.MiddleCenter;
            num.BackColor = Color.FromArgb(240, 242, 250);
            Label tip = MakeLabel("ตัวเลขนี้ตรงกับที่แสดงบนมือถือไหม? ถ้าคุณไม่ได้เป็นคนแตะ \"จับคู่\" บนมือถือ หรือตัวเลขไม่ตรง ให้กด ไม่อนุญาต", 20, 136, 380, 66);
            tip.ForeColor = grey;
            Button yes = new Button();
            yes.Text = "อนุญาต";
            yes.FlatStyle = FlatStyle.System;
            yes.SetBounds(200, 216, 100, 34);
            Button no = new Button();
            no.Text = "ไม่อนุญาต";
            no.FlatStyle = FlatStyle.System;
            no.SetBounds(306, 216, 100, 34);
            string myTag = tag;
            bool decided = false;
            yes.Click += delegate { decided = true; Decide(myTag, true); d.Close(); };
            no.Click += delegate { decided = true; Decide(myTag, false); d.Close(); };
            d.FormClosed += delegate { if (!decided && PromptTag == myTag) Decide(myTag, false); if (ask == d) ask = null; };
            d.Controls.AddRange(new Control[] { q, num, tip, yes, no });
            d.CancelButton = no;
            d.ActiveControl = no;   // ปุ่มที่ได้โฟกัสตอนเด้งขึ้นคือ "ไม่อนุญาต" — กด Enter/Space พลาดจะไม่กลายเป็นการอนุญาต
            ask = d;
            d.Show();
            d.Activate();
            tray.ShowBalloonTip(8000, "มีมือถือขอจับคู่", "\"" + PromptName + "\" — ตรวจตัวเลข " + PromptNumber + " แล้วกดอนุญาต", ToolTipIcon.Info);
        };

        System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
        t.Interval = 200;
        int n = 0;
        t.Tick += delegate
        {
            PollLeds();
            showAsk();
            windowShown = f.Visible;
            int old = oldCopies;
            setWarn(old);
            if (old > 0 && !warnBalloon && !f.Visible)
            {
                warnBalloon = true;
                tray.ShowBalloonTip(8000, "Phone Touchpad", "โปรแกรมช่วยรุ่นเก่ายังเปิดอยู่ ดับเบิลคลิกไอคอนนี้เพื่อปิดรุ่นเก่า", ToolTipIcon.Warning);
            }
            if (Connected)
            {
                status.Text = "● เชื่อมต่อกับมือถือแล้ว";
                status.ForeColor = Color.FromArgb(46, 125, 50);
                tray.Text = "Phone Touchpad - เชื่อมต่อแล้ว";
            }
            else
            {
                status.Text = "○ กำลังรอมือถือ…";
                status.ForeColor = Color.FromArgb(176, 120, 0);
                tray.Text = "Phone Touchpad - รอมือถือ";
            }
            if (n++ % 10 == 0)
            {
                pairedLabel.Text = PairedText;
                info.Text = ShotMode ? "คอมพิวเตอร์: MY-PC\r\nIP ของเครื่องนี้: 192.168.1.20"
                    : "คอมพิวเตอร์: " + Environment.MachineName + "\r\nIP ของเครื่องนี้: " + LocalAddresses();
            }
        };
        t.Start();

        // optional (used to make Store screenshots): PTW_SHOT=<png path> saves an image of this window after PTW_SHOT_DELAY ms, then the program exits
        string shotPath = Environment.GetEnvironmentVariable("PTW_SHOT");
        if (!string.IsNullOrEmpty(shotPath))
        {
            int delay; if (!int.TryParse(Environment.GetEnvironmentVariable("PTW_SHOT_DELAY"), out delay)) delay = 2000;
            System.Windows.Forms.Timer st = new System.Windows.Forms.Timer();
            st.Interval = delay;
            st.Tick += delegate
            {
                st.Stop();
                Form target = ask ?? f;
                Bitmap bmp = new Bitmap(target.Width, target.Height);
                target.DrawToBitmap(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height));
                bmp.Save(shotPath, System.Drawing.Imaging.ImageFormat.Png);
                if (ask != null) ask.Close();   // ปิดหน้าต่างถามโดยไม่ได้กด = ไม่อนุญาต (มือถือได้คำตอบก่อนโปรแกรมจบ)
                Quit(ctx);
            };
            st.Start();
        }

        // เปิดเองตอนล็อกอิน = อยู่เงียบๆ ที่ไอคอนข้างนาฬิกา ไม่ต้องเด้งหน้าต่าง (เปิดจากเมนู Start = แสดงหน้าต่าง)
        bool hidden = (StartedAtLogon() || StartHidden) && string.IsNullOrEmpty(shotPath);
        IntPtr created = f.Handle;   // สร้างหน้าต่างไว้ก่อนแม้ยังไม่แสดง — BeginInvoke จากเธรดอื่น (เปิดซ้ำ = ขอให้แสดงหน้าต่าง) ต้องมี handle
        if (!hidden) f.Show();
        Application.Run(ctx);
        t.Stop();
        tray.Dispose();
    }
}
'@

Add-Type -TypeDefinition $src -ReferencedAssemblies System.Windows.Forms, System.Drawing, System.Security, System.Core

$isTest = [bool]$TestCode -or [bool]$env:PTW_CONFIG_DIR
[PtwHelper]::ScriptPath = $PSCommandPath
[PtwHelper]::StartHidden = [bool]$Startup
if (-not $NoUi -and -not [PtwHelper]::ClaimInstance($isTest)) { exit }
[PtwHelper]::Start($TestCode, $LogReports, [bool]$AutoAllow)
if ($NoUi) {
    $end = (Get-Date).AddSeconds($(if ($Seconds -gt 0) { $Seconds } else { 3600 }))
    $was = $false
    while ((Get-Date) -lt $end) {
        Start-Sleep -Milliseconds 200
        $c = [PtwHelper]::Connected
        if ($c -ne $was) { Write-Output ("connected=" + $c + " reports=" + [PtwHelper]::Reports); $was = $c }
    }
    Write-Output ("done reports=" + [PtwHelper]::Reports)
    [PtwHelper]::Stop()
} else {
    [PtwHelper]::RunUi()
}
