﻿Phone Touchpad - helper for Windows 10 / 11 (script version, no installation)
=============================================================================

The easier way is the Microsoft Store version: open Microsoft Store and search for "Phone Touchpad".
This folder is the alternative for computers that cannot use the Store.

1. Double-click  Start-Touchpad-WiFi.bat
   A window opens and a Phone Touchpad icon appears next to the clock. You can close the window;
   the helper keeps running. To stop it, right-click the icon and choose the last item (Exit).
2. Put the phone and this computer on the same Wi-Fi (or connect this computer to the hotspot of the phone).
3. Open the Phone Touchpad app (1.24 or newer). It finds this computer by itself: tap Pair, check that the
   6-digit number matches the one in the window that pops up here, then click Allow (the left button).
   Older app versions ask for the 8-character pairing code shown in the helper window instead.

After the first run it starts by itself when you sign in to Windows and stays next to the clock without opening a window.
Untick the box in the helper window (the line that begins with a tick box) if you do not want that. No administrator rights are needed.
If you move this folder, run the .bat once more from the new place.
Help and details: https://9prasert.github.io/phone-numpad-privacy/touchpad-wifi.html


Phone Touchpad - โปรแกรมช่วยสำหรับ Windows 10 / 11 (แบบสคริปต์ ไม่ต้องติดตั้ง)
=============================================================================

ทางที่ง่ายกว่าคือรุ่นใน Microsoft Store: เปิด Microsoft Store แล้วค้นหา "Phone Touchpad"
โฟลเดอร์นี้เป็นทางสำรองสำหรับคอมพิวเตอร์ที่ใช้ Store ไม่ได้

1. ดับเบิลคลิก  Start-Touchpad-WiFi.bat
   จะมีหน้าต่างเปิดขึ้น และมีไอคอน Phone Touchpad ข้างนาฬิกา ปิดหน้าต่างได้ โปรแกรมยังทำงานอยู่
   จะหยุด ให้คลิกขวาที่ไอคอนแล้วเลือก "ออก"
2. ให้มือถือกับคอมพิวเตอร์เครื่องนี้อยู่ Wi-Fi เดียวกัน (หรือให้คอมพิวเตอร์ต่อ Hotspot ของมือถือ)
3. เปิดแอป Phone Touchpad (รุ่น 1.24 ขึ้นไป) แอปจะเจอคอมพิวเตอร์เครื่องนี้เอง แตะ "จับคู่" ดูว่าเลข 6 หลัก
   ตรงกับในหน้าต่างที่เด้งขึ้นบนเครื่องนี้ แล้วกด "อนุญาต"
   แอปรุ่นเก่ากว่านั้นจะถามรหัสจับคู่ 8 ตัวที่แสดงในหน้าต่างโปรแกรมช่วยแทน

หลังเปิดครั้งแรก โปรแกรมจะเปิดเองทุกครั้งที่เปิดเครื่อง และอยู่ที่ไอคอนข้างนาฬิกาโดยไม่เด้งหน้าต่าง
ถ้าไม่ต้องการ เอาเครื่องหมายออกจากช่อง "เปิดเองเมื่อเปิดเครื่อง" ในหน้าต่างโปรแกรมช่วย ไม่ต้องใช้สิทธิ์ผู้ดูแลระบบ
ถ้าย้ายโฟลเดอร์นี้ ให้ดับเบิลคลิก .bat จากที่ใหม่อีกหนึ่งครั้ง
วิธีใช้และรายละเอียด: https://9prasert.github.io/phone-numpad-privacy/touchpad-wifi.html
